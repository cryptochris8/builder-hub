# Builder Hub — Efficiency, Context Continuity & Intelligent Routing Upgrade
## Claude Code / Fable 5.1 Implementation Brief

### Mission
Upgrade the EXISTING Builder Hub rather than rebuilding it.

Builder Hub is the owner's personal multi-project development workspace/IDE. It can open many projects under the user's workspace, run multiple Claude Code terminals at once, and should increasingly act as the orchestration layer between projects, shared tools, context, models, and previews.

The priority order is:

1. CORRECTNESS and quality of output.
2. CONTEXT continuity and awareness of the owner's existing creator stack.
3. REDUCE redundant reading/reasoning and token/credit waste.
4. ROUTE work to the least expensive model/effort level that can perform it reliably.
5. KEEP the desktop clean by handling files, previews, and web content inside Builder Hub where practical.
6. PRESERVE the current Builder Hub behavior that already works.

Do NOT sacrifice quality simply to reduce token usage. A high-quality trailer produced with full awareness of the existing Trailer Kit is preferable to a cheaper model reinventing an inferior trailer workflow.

---

# 1. FIRST PHASE: AUDIT THE CURRENT BUILDER HUB

Before implementing anything:

- Inspect the existing Builder Hub codebase and architecture.
- Identify features below that are already implemented, partially implemented, or broken.
- Inspect existing project/global Claude instructions, memory/context mechanisms, hooks, caches, MCP/config files, terminal orchestration, and any project registry.
- Reuse working systems rather than duplicating them.
- Repair regressions discovered during the audit.
- Do not delete or replace working behavior without a clear reason.
- Create a short `BUILDER_HUB_AUDIT.md` explaining:
  - current architecture;
  - what already exists;
  - what is being reused;
  - problems found;
  - changes made;
  - remaining limitations.

Avoid repeatedly feeding the entire repository or every project to a model. Use targeted discovery and cache/index results when safe.

---

# 2. INTELLIGENT MODEL + EFFORT ROUTER

Builder Hub should help select an appropriate Claude model and effort level for the current task.

## Desired behavior
The router should classify work by complexity/risk, for example:

### Low-cost / low-effort candidates
- file lookup;
- simple edits;
- renaming/moving files;
- straightforward CSS/text changes;
- searching a known codebase;
- running tests/builds;
- reading logs;
- mechanical refactors;
- repetitive asset operations.

### Medium candidates
- ordinary feature implementation;
- debugging with a reasonably clear failure;
- integrating an existing internal tool;
- moderate refactors;
- normal game/UI iteration.

### High / Fable 5.1 / high-effort candidates
- architecture;
- difficult bugs;
- novel systems;
- multi-project integration;
- large migrations;
- complex game logic;
- tasks that have failed on weaker models;
- planning where a bad decision would create significant rework.

## Quality-first escalation
Implement escalation signals such as:
- repeated failed attempts;
- test/build failures that remain unexplained;
- uncertainty/conflicting evidence;
- large cross-project changes;
- architectural decisions;
- security/data-loss risk;
- user explicitly requests maximum quality.

## De-escalation
When the difficult portion is complete, Builder Hub should be able to recommend returning to a cheaper model/effort level for mechanical follow-through.

## Switching policy
Initially prefer a visible recommendation such as:

> Suggested: switch to [model] / [effort] because [short reason].

If Claude Code exposes a reliable supported mechanism to change model/effort programmatically, design an OPTIONAL auto-routing mode. Never depend on undocumented UI automation or brittle hacks.

Provide:
- `Manual` — never change automatically.
- `Suggest` — default; recommend changes.
- `Auto` — only if supported reliably, with user-configurable rules.
- `Lock` — pin a terminal/task to a selected model/effort.

Do not switch models in the middle of an atomic operation if doing so risks losing critical working context.

---

# 3. PERSISTENT CONTEXT / MODEL HANDOFF LAYER

The biggest goal is that switching models, clearing context, opening another terminal, or resuming later should NOT mean "start from zero."

Builder Hub should own a model-independent project state outside any single Claude conversation.

Create a lightweight context system with layers such as:

## A. Global Builder Hub context
Stable information useful across projects:
- workspace/project registry;
- shared creator stack;
- preferred stacks/conventions;
- shared internal tools;
- reusable services/assets;
- locations and usage instructions.

## B. Project context
Each project should have a concise durable state document/database record containing:
- project purpose;
- stack;
- important architecture;
- current branch/state when available;
- important commands;
- dependencies/services;
- shared tools it uses;
- decisions already made;
- current tasks;
- known bugs;
- recent completed work;
- files/directories most likely to matter.

## C. Active task handoff
Maintain a small current-task packet:
- objective;
- what was attempted;
- files changed;
- decisions;
- test/build status;
- unresolved issues;
- recommended next action.

When a model changes or context is cleared, inject/retrieve this concise handoff first rather than forcing a full reread.

## D. Retrieval on demand
Do NOT stuff every detail into every prompt. Retrieve deeper context only when the task needs it.

Use a progressive approach:
1. compact global/project/task summary;
2. targeted lookup of relevant registry entries/files;
3. deeper repository reading only when necessary.

## E. Freshness
Context must not become a stale source of truth.
- Include timestamps/version/hash where useful.
- Revalidate important assumptions against actual files before destructive or architectural changes.
- Update task/project state after meaningful work.
- Never allow a summary to override current source code.

---

# 4. SHARED TOOL / PROJECT REGISTRY ("CREATOR STACK")

Builder Hub needs explicit awareness of reusable tools and related projects.

Example: `Income Kit` contains reusable creator utilities, including the existing Trailer/Video Creator. If a game project asks to "make a trailer with our trailer kit," Claude should locate and use the established tool rather than inventing a new trailer generator.

Create or improve a machine-readable registry, e.g.:

```yaml
projects:
  income-kit:
    path: "<discover current path>"
    type: shared-tools
    aliases: ["Income Kit"]
    capabilities:
      - id: trailer-kit
        aliases: ["trailer kit", "video creator", "trailer creator"]
        purpose: "Create game/product trailers using the owner's established pipeline"
        entrypoints: []
        docs: []
  gnarly-nutmeg:
    path: "<discover current path>"
    type: game
```

Do NOT hard-code guessed paths if Builder Hub already has a workspace/project discovery system. Discover the real structure.

Registry requirements:
- aliases/natural-language names;
- project path;
- project type;
- capabilities/tools exposed;
- relevant docs/entry points;
- safe usage notes;
- dependencies;
- optional tags.

Add a quick command/UI to refresh/reindex the registry when projects change.

### Cross-project guardrail
Awareness does not mean permission to edit everything.
- Read/reference another project when needed.
- Before modifying another project's source, clearly identify that cross-project modification.
- Prefer consuming shared tools through stable interfaces rather than copying their implementation into every project.

---

# 5. TOKEN/CREDIT EFFICIENCY WITHOUT QUALITY LOSS

Implement an efficiency strategy around reuse, caching, and targeted retrieval.

## Principles
- Do not repeatedly reread unchanged files.
- Do not rescan every project for every terminal.
- Do not include irrelevant context "just in case."
- Do not summarize a summary repeatedly until it loses important details.
- Cache expensive discovery where appropriate.
- Invalidate caches when source files change.
- Prefer deterministic local operations (search, grep, AST/index, tests, filesystem metadata) over model reasoning when a model is not needed.

If the current Claude Code version provides a supported prompt/context caching feature, use it where beneficial. Detect current supported behavior from installed tooling/documentation rather than assuming a specific API based on this brief.

### Correctness override
If cached context is insufficient or potentially stale, spend the tokens and reread the authoritative files. Quality wins.

---

# 6. INTERNAL FILE / WEB / PREVIEW VIEWERS

Builder Hub should minimize the "six Chrome windows" problem.

Default policy: **open inside Builder Hub whenever practical.**

Support/repair internal tabs for:
- source files;
- Markdown;
- JSON/YAML/text;
- images;
- PDFs if feasible;
- local HTML/game previews;
- localhost/dev servers;
- documentation/web pages using a safe embedded webview/browser where supported.

Provide:
- tabbed interface;
- back/forward/refresh for web previews;
- open externally button;
- copy path/URL;
- reveal in filesystem;
- close/reopen recent tabs.

External apps should be fallback behavior when:
- embedding is blocked;
- authentication/security requires an external browser;
- a file type is unsupported;
- the user explicitly chooses external.

Do not weaken webview security merely to keep content internal.

---

# 7. MULTI-TERMINAL / CROSS-TERMINAL AWARENESS

Multiple terminals can work on different projects simultaneously.

Builder Hub should provide lightweight awareness without dumping every transcript into every other terminal.

Maintain shared state such as:
- terminal ID;
- project;
- current task;
- model/effort;
- files currently being modified;
- recent important action;
- build/test status.

Useful behaviors:
- warn if two terminals are about to edit the same file;
- allow a terminal to query what another terminal is doing;
- publish meaningful task-state updates;
- avoid blindly injecting full terminal histories.

Think "shared coordination board," not "every agent reads every conversation."

---

# 8. USER EXPERIENCE

Add a small Builder Hub status/control surface showing, per active terminal:
- Project
- Task
- Current model
- Effort
- Router recommendation
- Context freshness/status
- Token-saving/cache status if available
- Cross-project tools currently in use

Potential actions:
- Apply model recommendation
- Lock model
- Refresh context
- Open project context
- Open Creator Stack registry
- Publish handoff
- Reindex project
- Open internally / externally

Keep this compact. Builder Hub is an IDE, not a dashboard product.

---

# 9. FAILURE SAFETY

Before large changes:
- preserve/commit current working state if the repository workflow allows;
- do not overwrite user data;
- avoid destructive migrations;
- make context/index data rebuildable;
- make cache deletion safe;
- keep registry/context files human-readable where practical.

If a feature depends on an unsupported Claude Code capability, implement the best supported approximation and document the limitation instead of hacking around it.

---

# 10. IMPLEMENTATION ORDER

Use Fable 5.1 primarily for architecture, audit, and difficult integration. Once architecture is settled, use cheaper models/effort for mechanical implementation where practical.

Recommended phases:

1. Audit existing Builder Hub.
2. Fix existing regressions.
3. Establish/normalize Project + Creator Stack Registry.
4. Establish persistent global/project/task context + handoff.
5. Add targeted retrieval/cache/invalidation.
6. Implement model/effort recommendation engine.
7. Add optional supported auto-routing if possible.
8. Finish/repair internal viewer behavior.
9. Add cross-terminal coordination.
10. Add compact UI controls/status.
11. Test with real projects.
12. Document.

Do not do a cosmetic rewrite before the orchestration layer works.

---

# 11. REAL-WORLD ACCEPTANCE TESTS

Test against actual workflows, not toy examples.

### Test A — Trailer Kit discovery
From a game project, ask:
> Create a trailer using our trailer kit.

PASS if Builder Hub/Claude:
- recognizes that an established shared trailer tool exists;
- locates it through the registry/context;
- reads the minimum documentation/code needed;
- uses/integrates that workflow;
- does NOT begin building a redundant trailer system.

### Test B — Model switch continuity
Begin a feature on a powerful model, then switch to a cheaper model.

PASS if the new model receives enough project/task state to continue correctly without the user re-explaining the work or a full repository reread.

### Test C — Context clear
Clear/restart Claude context during a task.

PASS if Builder Hub reconstructs a concise accurate handoff and retrieves deeper files only as required.

### Test D — Easy task routing
Ask for a simple text/CSS change while using an expensive model/high effort.

PASS if Builder Hub recommends a cheaper appropriate model/effort without interrupting the task.

### Test E — Escalation
Give a difficult bug to a cheaper model and allow repeated failure.

PASS if Builder Hub recognizes failure/uncertainty and recommends escalation.

### Test F — Internal preview
Open a local game preview or documentation link.

PASS if it opens in a Builder Hub tab when technically supported, with an obvious external-open fallback.

### Test G — Parallel terminals
Have two terminals work simultaneously.

PASS if they can see lightweight shared status and Builder Hub warns about conflicting file edits without sharing unnecessary transcript context.

### Test H — Stale cache
Modify a source file outside the active Claude session.

PASS if Builder Hub detects invalidation/freshness changes before relying on cached context for important work.

---

# 12. DELIVERABLES

At completion, provide:

- working code integrated into existing Builder Hub;
- `BUILDER_HUB_AUDIT.md`;
- `BUILDER_HUB_ARCHITECTURE.md`;
- `CREATOR_STACK.md` or equivalent registry documentation;
- `CONTEXT_AND_ROUTING.md`;
- configuration examples/defaults;
- tests for critical routing/context/registry logic;
- concise changelog;
- list of limitations that depend on Claude Code/model-provider capabilities.

Also provide a short "How Chris Uses This" section with examples:
- starting a project;
- using a shared tool from Income Kit;
- switching models;
- clearing context;
- manually refreshing context;
- overriding/locking routing.

---

# 13. IMPORTANT DESIGN RULES

1. Existing source code is authoritative.
2. Existing working Builder Hub features should be preserved.
3. Correctness > token savings.
4. Persistent context belongs to Builder Hub, not to one model conversation.
5. Use summaries/indexes for orientation; use source files for truth.
6. Shared tools should be discovered and reused, not reinvented.
7. Cross-project awareness should not cause accidental cross-project edits.
8. Prefer supported Claude Code mechanisms; do not build brittle UI hacks.
9. Routing should be explainable and overridable.
10. The entire system should still work if the user disables auto-routing.
11. Context/cache/index data must be recoverable/rebuildable.
12. Optimize Fable 5.1 usage: use it where its reasoning matters, then delegate mechanical work when safe.

---

# 14. STARTING INSTRUCTION FOR FABLE 5.1

Begin by auditing the existing Builder Hub. Do not immediately rewrite it.

Map the current implementation against this brief and tell me what already exists, what is partially working, and what needs to be added or repaired. Then create a phased implementation plan that minimizes regressions and unnecessary token usage.

After the audit, proceed with implementation unless there is a genuinely blocking architectural decision that requires user input. Make reasonable implementation choices independently where the intent in this document is clear.

The finished result should make Builder Hub feel like the persistent brain/orchestrator for the owner's entire creator workspace: projects remain separate, but Builder Hub knows what tools exist, carries task state across terminals/models/context resets, opens work internally where possible, and spends premium model tokens only when premium reasoning is actually useful.
