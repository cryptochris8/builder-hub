# Builder Hub Upgrade Handoff

Give `BUILDER_HUB_UPGRADE_SPEC.md` to Claude Code / Fable 5.1 from the root of the existing Builder Hub repository.

Recommended first prompt:

> Read BUILDER_HUB_UPGRADE_SPEC.md completely. Audit the existing Builder Hub before changing anything. Preserve working behavior, identify which requested systems already exist, then implement the upgrade in phases. Correctness is more important than token savings. Use Fable 5.1 for architecture/difficult work and recommend/delegate mechanical work to cheaper models when safe.

This package intentionally does not contain Builder Hub source code. It is an implementation brief for upgrading the existing installation.
