# Builder Hub v1.1 — Context-Aware Routing & Switching-Cost Addendum

## Mission
This is a focused PATCH to the completed Builder Hub upgrade, not a rebuild.

The existing router primarily answers: "How powerful a model/effort does the latest task require?"
v1.1 must also answer: "What knowledge and continuity would be lost by switching models right now?"

Preserve all working behavior. Correctness and continuity come before token savings.

## Implementation budget
- Prefer one primary agent/session.
- Maximum parallel agents: 3.
- Do not repeat the broad Builder Hub audit.
- Do not inspect unrelated projects.
- Reuse the existing router, RouterSignals, board reducer, recaps, task packets, project context, hooks, SessionBar, and context/status mechanisms.
- Targeted tests first, then relevant regression tests.

## Audit findings to use as the starting point
Current recommend() receives only:
- latest prompt text;
- RouterSignals counters;
- current model/effort when known;
- project registry.

Signals currently include failures/passes, distinct files/projects, mechanical-turn streak, uncertainty hits, max-quality, and risk words.

Current routing handles task complexity, escalation and mechanical downgrade reasonably well, but DOES NOT reason about:
- context-window utilization;
- context value;
- architectural decisions accumulated in-session;
- semantic importance of code changes;
- unresolved prior reasoning;
- whether important state is already captured in memory/handoff;
- switching cost.

The audit also found that used_percentage can be supplied by the status line, but the audited machine did not have that status line installed. Recaps/task packets and PostToolUse contain useful signals, but the router does not use them.

## New routing model
Keep existing task-requirement logic and add a separate Switching Cost calculation.

Conceptually:
Switching Cost = f(Context Size, Context Value, Task Continuity, Capture Adequacy)

Mental model:
Cost ~ Size × Value × Continuity × (1 - Capture Adequacy)

Do not blindly use literal multiplication unless normalized values make that appropriate. Favor explainable deterministic scoring.

## 1. Context Size
Reliably obtain current context utilization.

Preferred:
- supported Claude Code context/status data such as used_percentage.

Fallback:
- reliable locally available session/transcript usage metadata when supported.

Requirements:
- Detect missing status/context setup.
- Do not require Chris to remember manual setup if Builder Hub can safely configure it.
- If exact data is unavailable, mark it Estimated or Unknown.
- Never invent precision.

Expose Low / Moderate / High / Very High plus raw percentage when available.

## 2. Context Value
Large does not equal valuable.

Increase value for signals such as:
- substantive edits/writes;
- successful tests/builds following changes;
- architecture/design decisions;
- bug root causes;
- active unresolved implementation reasoning;
- multi-file dependencies;
- newly learned constraints;
- recent substantive work;
- cross-project integration decisions;
- user-approved implementation choices.

Decrease value for:
- search/read-heavy activity with little currently useful output;
- dead ends;
- obsolete exploration;
- long stretches since meaningful work;
- unrelated prior work;
- already-captured/compacted information.

Important: research without edits can still be valuable when it establishes a constraint or negative finding.

Classify Low / Moderate / High / Critical. Prefer deterministic local proxies accumulated incrementally rather than transcript rereads.

## 3. Task Continuity
Ask: how dependent is the NEXT task on the valuable knowledge in the CURRENT session?

Signals:
- same project;
- same task packet/objective;
- same files/components;
- same bug/feature;
- semantic overlap with current objective/recent recap;
- project switch;
- clear task-boundary language;
- prior objective completion.

Classify Very Low / Low / Moderate / High.

Example: 95% valuable Builder Hub context followed by "fix the remaining router test" = high continuity.
The same session followed by "open Gnarly Nutmeg and change PLAY to START" = very low continuity.

## 4. Capture Adequacy
Valuable context is cheaper to leave when Builder Hub has already preserved it accurately.

Evaluate:
- active task packet;
- recent recap;
- project context;
- decisions;
- known bugs;
- recent work;
- published handoff;
- source/tests where appropriate.

Signals include:
- substantive edits since last recap;
- decisions after last capture;
- unresolved failures after capture;
- whether a handoff followed the last substantive turn;
- whether objective/next steps are represented;
- whether relevant files changed after capture.

Classify Poor / Partial / Good / Excellent.
A recap's mere existence does not make capture adequate.

## Switching policy
When task complexity suggests downgrade but switching cost is HIGH:
- HOLD current model/effort.
- Never auto-downgrade.
- Explain why.
- Recommend reassessment at the next task boundary.
- Offer "Prepare handoff & switch."

Example:
Remain on Fable / UltraCode
Immediate task complexity: Low
Context utilization: 91%
Context value: High
Task continuity: High
Capture adequacy: Partial
Switching risk: High
Recommendation: Finish this task on Fable and reassess at the next task boundary.

When switching cost is LOW:
- allow normal downgrade recommendation/apply behavior;
- explain that continuity risk is low.

When MODERATE:
- suggestion allowed;
- no automatic downgrade;
- offer handoff first where useful.

Switching-cost logic must NEVER block necessary escalation to a more capable model for repeated failures, high-risk work, architecture, explicit max-quality, or existing escalation signals.

## Task boundaries
Add lightweight task-boundary detection using signals such as:
- explicit completion;
- project change;
- material objective change;
- task packet completion;
- passing tests followed by unrelated prompt;
- "next", "now let's", "switch to", "that's finished";
- new project opened.

At a strong boundary:
- capture important state;
- reduce old-context continuity weighting;
- reassess model/effort;
- permit appropriate downgrade more readily.

When uncertain, prefer suggestion/hold over automatic switching.

## Handoff Before Switch
Add an action:
Prepare handoff & switch

The concise handoff should include:
- current objective;
- relevant decisions;
- files changed;
- implementation state;
- tests/build status;
- unresolved issues;
- next action;
- only context needed by the incoming model.

Update persistent state before switching. Never dump the full transcript.

## SessionBar / UI
Extend the existing recommendation UI rather than creating a new dashboard.

When useful show:
- recommended model/effort;
- task complexity;
- context utilization;
- context value;
- task continuity;
- capture adequacy;
- switching risk;
- concise reason.

Actions can include:
- Apply
- Stay
- Lock
- Prepare handoff & switch
- Reassess
- Dismiss

Keep it compact; detailed scoring may be expandable.

## Auto-mode safety
Never automatically DOWNGRADE when:
- switching risk is High;
- capture is Poor while value is High/Critical;
- unresolved failure/fix is active;
- continuity cannot be determined confidently.

Auto downgrade only when task requirement supports it, confidence is sufficient, switching risk is Low, and existing lock/dismissal/risk guards permit it.

User choice always overrides routing.

## Optional model-assisted valuation
Do not make premium-model calls every turn just to score context.

Primary scoring must be deterministic/local. If useful, an OPTIONAL inexpensive model may analyze only compact artifacts such as recaps/task packet/project context. Cache this until meaningful state changes. Never reread the full transcript merely to decide whether to save tokens.

## Minimal agent/concurrency governance foundation
Today's real-world run demonstrated another cost risk: a premium model can launch a very large parallel swarm.

Do NOT turn v1.1 into a full budgeting project. If straightforward within the current architecture:
- record active/planned agent count when available;
- distinguish premium versus cheaper workers when possible;
- support a configurable concurrency ceiling;
- require approval before exceptionally large premium-agent swarms;
- expose state for a future projected-cost governor.

If this is not small, document it as a v1.2 proposal rather than expanding scope.

Long-term Builder Hub should reason about model + effort + agent count + justified parallelism.

## Acceptance tests
A. Valuable 95% context + simple continuation: hold current premium model; High switching risk.
B. Low-value 95% context + simple task: downgrade may be recommended.
C. Valuable 95% context + unrelated new project: continuity Low; downgrade may be appropriate.
D. Valuable context + excellent handoff: capture lowers switching risk and handoff/switch succeeds.
E. Valuable context + substantive uncaptured changes: downgrade held or handoff required.
F. Repeated failure/high-risk architecture: switching cost does not block escalation.
G. Missing exact context percentage: estimate reliably or show Unknown; never fake it.
H. Complex task completed then clearly unrelated trivial task: boundary detected and router reassesses.

## Regression requirements
Preserve existing behavior for:
- failure escalation;
- uncertainty escalation;
- max-quality;
- risk;
- cross-project signals;
- mechanical streak;
- locks;
- dismissal;
- manual selection;
- SessionBar;
- persistent context/task packets.

Add unit tests for switching-cost scoring and policy. Prefer pure deterministic scoring functions.

## Deliverables
Provide:
- integrated code;
- tests;
- concise changelog;
- documentation of signals/scoring;
- explanation of context-usage source/fallback;
- confirmation of missing-status-line handling;
- any v1.2 recommendation for deeper agent/concurrency/projected-cost governance.

## Final implementation instruction
Read this addendum and inspect ONLY relevant router, session-state, board-reducer, recap/task-packet, hook, status/context-usage and SessionBar code.

Give a SHORT implementation plan, then proceed through implementation, testing, debugging and documentation unless a genuinely blocking decision requires user input.

MAXIMUM PARALLEL AGENTS: 3.

The desired behavior is no longer:
"The next prompt is easy, therefore switch."

It is:
"The next prompt is easy and a cheaper model could do it. Before recommending that switch, Builder Hub also understands what this session knows, how relevant that knowledge is to the next task, and how safely that knowledge has already been preserved."
