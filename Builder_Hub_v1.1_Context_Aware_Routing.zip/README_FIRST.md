# README FIRST

This ZIP is a focused v1.1 patch for the ALREADY COMPLETED Builder Hub upgrade.

Recommended Claude Code instruction:

Read `BUILDER_HUB_V1_1_CONTEXT_ROUTING.md` completely.

This is a focused patch, NOT a rebuild. Preserve the completed Builder Hub upgrade.

Use the audit findings in the document as the starting point and verify only the relevant implementation. Do not repeat the broad audit or inspect unrelated projects.

IMPORTANT: Do not launch a large parallel-agent swarm. Prefer one primary agent/session and use NO MORE THAN 3 parallel agents for this patch.

Implement context-aware switching cost in the existing router, test it, debug it, and document it. Give me a short implementation plan first, then proceed without stopping for approval unless there is a genuinely blocking architectural decision.
